﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNewORder = New System.Windows.Forms.Button()
        Me.btnData = New System.Windows.Forms.Button()
        Me.btnOrderMaterial = New System.Windows.Forms.Button()
        Me.btnPenghasilan = New System.Windows.Forms.Button()
        Me.btnEXIT = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label1.Font = New System.Drawing.Font("Humnst777 Blk BT", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(169, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 40)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "MAIN MENU"
        '
        'btnNewORder
        '
        Me.btnNewORder.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewORder.Location = New System.Drawing.Point(66, 146)
        Me.btnNewORder.Name = "btnNewORder"
        Me.btnNewORder.Size = New System.Drawing.Size(163, 82)
        Me.btnNewORder.TabIndex = 1
        Me.btnNewORder.Text = "&New Order"
        Me.btnNewORder.UseVisualStyleBackColor = True
        '
        'btnData
        '
        Me.btnData.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnData.Location = New System.Drawing.Point(66, 249)
        Me.btnData.Name = "btnData"
        Me.btnData.Size = New System.Drawing.Size(163, 82)
        Me.btnData.TabIndex = 2
        Me.btnData.Text = "&Data Karyawan"
        Me.btnData.UseVisualStyleBackColor = True
        '
        'btnOrderMaterial
        '
        Me.btnOrderMaterial.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderMaterial.Location = New System.Drawing.Point(312, 146)
        Me.btnOrderMaterial.Name = "btnOrderMaterial"
        Me.btnOrderMaterial.Size = New System.Drawing.Size(163, 82)
        Me.btnOrderMaterial.TabIndex = 3
        Me.btnOrderMaterial.Text = "&Order Material"
        Me.btnOrderMaterial.UseVisualStyleBackColor = True
        '
        'btnPenghasilan
        '
        Me.btnPenghasilan.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPenghasilan.Location = New System.Drawing.Point(312, 249)
        Me.btnPenghasilan.Name = "btnPenghasilan"
        Me.btnPenghasilan.Size = New System.Drawing.Size(163, 82)
        Me.btnPenghasilan.TabIndex = 4
        Me.btnPenghasilan.Text = "&Penghasilan"
        Me.btnPenghasilan.UseVisualStyleBackColor = True
        '
        'btnEXIT
        '
        Me.btnEXIT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEXIT.Location = New System.Drawing.Point(201, 376)
        Me.btnEXIT.Name = "btnEXIT"
        Me.btnEXIT.Size = New System.Drawing.Size(163, 43)
        Me.btnEXIT.TabIndex = 5
        Me.btnEXIT.Text = "&EXIT"
        Me.btnEXIT.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Label2.Font = New System.Drawing.Font("Humnst777 Blk BT", 36.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(120, -1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(331, 60)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Welcome to "
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel1.Location = New System.Drawing.Point(-1, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(556, 111)
        Me.Panel1.TabIndex = 7
        '
        'Form_MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 444)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnEXIT)
        Me.Controls.Add(Me.btnPenghasilan)
        Me.Controls.Add(Me.btnOrderMaterial)
        Me.Controls.Add(Me.btnData)
        Me.Controls.Add(Me.btnNewORder)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form_MainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Welcome to Main Menu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnNewORder As Button
    Friend WithEvents btnData As Button
    Friend WithEvents btnOrderMaterial As Button
    Friend WithEvents btnPenghasilan As Button
    Friend WithEvents btnEXIT As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
End Class
