﻿Public Class Form_OrderMaterial
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Form_OrderMaterial_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_Proses_Click(sender As Object, e As EventArgs) Handles btn_Proses.Click
        MsgBox("Data dengan Kode Barang " & cbKode.SelectedItem & " telah berhasil di Proses!", MsgBoxStyle.Information, "Data Tersimpan!")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tJenis.Text = ""
        tNama.Text = ""
        tQTY.Text = ""
        cbSatuan.Text = "Pilih"
        cbKode.Text = "Silahkan dipilih"

    End Sub
End Class