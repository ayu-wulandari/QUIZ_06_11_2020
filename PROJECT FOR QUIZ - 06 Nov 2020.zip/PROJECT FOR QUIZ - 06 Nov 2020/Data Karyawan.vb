﻿Public Class Form_Data_Karyawan
    Private Sub cbgolongan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbgolongan.SelectedIndexChanged
        Select Case cbgolongan.Text
            Case "I"
                ttunjanga.Text = 1000000
            Case "II"
                ttunjanga.Text = 750000
            Case "III"
                ttunjanga.Text = 500000
            Case Else
                ttunjanga.Text = 0
        End Select
    End Sub

    Private Sub ttotal_TextChanged(sender As Object, e As EventArgs) Handles ttotal.TextChanged

    End Sub

    Private Sub ttunjanga_TextChanged(sender As Object, e As EventArgs) Handles ttunjanga.TextChanged

    End Sub

    Private Sub btn_Proses_Click(sender As Object, e As EventArgs) Handles btn_Proses.Click
        MsgBox("Data Karyawan dengan ID " & tID.Text & " dan Atas Nama " & tnama.Text & " telah berhasil di simpan!", MsgBoxStyle.Information, "Data Tersimpan!")
    End Sub

    Private Sub tgaji_TextChanged(sender As Object, e As EventArgs) Handles tgaji.TextChanged
        ttotal.Text = Val(tgaji.Text) + Val(ttunjanga.Text)
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tID.Text = ""
        talamat.Text = ""
        tgaji.Text = ""
        thp.Text = ""
        tjabaatan.Text = ""
        tnama.Text = ""
        ttotal.Text = ""
        ttunjanga.Text = ""
        cbgolongan.Text = "Pilih"
        cbstatus.Text = "Pilih"


    End Sub
End Class