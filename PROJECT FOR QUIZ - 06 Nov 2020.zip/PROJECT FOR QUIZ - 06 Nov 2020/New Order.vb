﻿Public Class Form_NewOrder
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tnamabarang.Text = ""
        tnamacustomer.Text = ""
        cbKode.Text = "Silahkan dipilih"
        tJumlah.Text = ""
        cbSatuan.Text = "Silahkan dipilih"

    End Sub

    Private Sub btn_Proses_Click(sender As Object, e As EventArgs) Handles btn_Proses.Click
        MsgBox("Orderan terbaru atas nama " & tnamacustomer.Text & " telah berhasil disimpan!", MsgBoxStyle.Information, "Data Tersimpan!")
    End Sub
End Class