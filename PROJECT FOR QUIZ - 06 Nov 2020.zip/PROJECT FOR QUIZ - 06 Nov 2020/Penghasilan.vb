﻿Public Class Form_Penghasilan
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        cbKode.Text = "Silahkan Pilih"
        tHarga.Text = ""
        tNama.Text = ""
        tQTY.Text = ""
        tTotal.Text = ""
    End Sub

    Private Sub btn_Proses_Click(sender As Object, e As EventArgs) Handles btn_Proses.Click
        MsgBox("Data dengan Kode Barang " & cbKode.SelectedItem & " dan dengan Total Amount " & tTotal.Text & " telah berhasil di simpan!", MsgBoxStyle.Information, "Data Tersimpan!")
    End Sub

    Private Sub tTotal_TextChanged(sender As Object, e As EventArgs) Handles tTotal.TextChanged

    End Sub

    Private Sub tQTY_TextChanged(sender As Object, e As EventArgs) Handles tQTY.TextChanged
        tTotal.Text = Val(tHarga.Text) * Val(tQTY.Text)
    End Sub
End Class