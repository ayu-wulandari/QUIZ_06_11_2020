﻿Public Class Form_MainMenu
    Private Sub btnNewORder_Click(sender As Object, e As EventArgs) Handles btnNewORder.Click
        Form_NewOrder.Show()

    End Sub

    Private Sub btnOrderMaterial_Click(sender As Object, e As EventArgs) Handles btnOrderMaterial.Click
        Form_OrderMaterial.Show()

    End Sub

    Private Sub btnData_Click(sender As Object, e As EventArgs) Handles btnData.Click
        Form_Data_Karyawan.Show()

    End Sub

    Private Sub btnPenghasilan_Click(sender As Object, e As EventArgs) Handles btnPenghasilan.Click
        Form_Penghasilan.Show()

    End Sub

    Private Sub btnEXIT_Click(sender As Object, e As EventArgs) Handles btnEXIT.Click
        End

    End Sub
End Class
